import react, {useEffect, useState} from 'react';
import StudentService from '../services/StudentService';
import {Link} from 'react-router-dom';

const Student=()=>{
    const [student, setStudent]= useState();
    useEffect(()=>{
        allStudent();
    },[]);
    const allStudent=()=>{
        StudentService.getAll().then(res=>{
            setStudent(res.data);
            console.log(res.data)
        })
    }
    return(
        <table className='table table-hover'>
            <tr>
                <th>ID</th>
                <th>Student ID</th>
                <th>Student Name</th>
                <th>Batch No</th>
            </tr>
            {student && student.map((item,index)=>(
            <tr key={index}>
                <td>{++index}</td>
                <td>{item.student_id}</td>
                <td>{item.name}</td>
                <td>{item.batch_number}</td>
            </tr>
            
        ))}</table>
    );
};

export default Student;