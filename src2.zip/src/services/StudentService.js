import http from "../http-common";
const create = data=>{
    return http.post('create.php',data);
}

const getAll = data=>{
    return http.post('retrive.php');
}

const StudentService = {
    create,getAll
}

export default StudentService;